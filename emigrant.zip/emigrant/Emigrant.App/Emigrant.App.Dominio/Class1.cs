﻿using System;

namespace Emigrant.App.Dominio
{
    public class Class1
    {
    }
}
