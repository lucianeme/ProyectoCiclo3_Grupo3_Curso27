using System.Collections.Generic;
using Emigrant.App.Dominio;
using System.Linq;
using System;
 
namespace Emigrant.App.Persistencia.AppRepositorios
{
    public class RepositorioMigrante
    {
        List<Migrante> migrantes;
 
    public RepositorioMigrante()
        {
            migrantes= new List<Migrante>()
            {
                new Migrante{id=1,nombre="Audi"},
                new Migrante{id=2,nombre="Toyota"},
                new Migrante{id=3,nombre="Mazda"}
 
            };
        }
 
        public IEnumerable<Migrante> GetAll()
        {
            return migrantes;
        }
 
        public Migrante GetMigranteWithId(int id){
            return migrantes.SingleOrDefault(b => b.id == id);
        }

        public Migrante Update(Migrante newMigrante){
            var migrant= migrantes.SingleOrDefault(b => b.id == newMigrante.id);
            if(migrant != null){
                migrant.nombre = newMigrante.nombre;
                migrant.apellidos = newMigrante.apellidos;
                migrant.tipodocumento = newMigrante.tipodocumento;
                migrant.numeroidentificacion = newMigrante.numeroidentificacion;
                migrant.paisorigen = newMigrante.paisorigen;
            }
            return migrant;
        }

        public Migrante Create(Migrante newMigrante)
        {
            if(migrantes.Count > 0){
                newMigrante.id=migrantes.Max(r => r.id) +1; 
            }else{
               newMigrante.id = 1; 
            }
            migrantes.Add(newMigrante);
            return newMigrante;
        }

        public Migrante Delete(int id)
        {
            var migrant= migrantes.SingleOrDefault(b => b.id == id);
            migrantes.Remove(migrant);
            return migrant;
        }



    }
}
