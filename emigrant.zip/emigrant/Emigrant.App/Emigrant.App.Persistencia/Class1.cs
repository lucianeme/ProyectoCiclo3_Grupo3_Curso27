﻿using System;

namespace Emigrant.App.Persistencia
{
    public class Class1
    {
    }
}
