﻿using System;

namespace Emigrant.App.Servicios
{
    public class Class1
    {
    }
}
